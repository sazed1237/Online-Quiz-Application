/*
 * Project: Online Quiz Application
 * Language: Java
 * Description: A simple Java application for taking quizzes on various topics.
 * Features:
 * - Add Questions to the Quiz
 * - Take Quiz
 * - Display Quiz Results
 * - Randomize Questions for Each Attempt
 */

import java.util.*;

public class Main {

    private static final List<Question> questions = new ArrayList<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;

        while (true) {
            System.out.println("\nOnline Quiz Application Menu:");
            System.out.println("1. Add Question");
            System.out.println("2. Take Quiz");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");

            choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    addQuestion(scanner);
                    break;
                case 2:
                    takeQuiz(scanner);
                    break;
                case 3:
                    System.out.println("Exiting Online Quiz Application. Goodbye!");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addQuestion(Scanner scanner) {
        System.out.print("Enter question: ");
        String questionText = scanner.nextLine();

        System.out.print("Enter option A: ");
        String optionA = scanner.nextLine();

        System.out.print("Enter option B: ");
        String optionB = scanner.nextLine();

        System.out.print("Enter option C: ");
        String optionC = scanner.nextLine();

        System.out.print("Enter option D: ");
        String optionD = scanner.nextLine();

        System.out.print("Enter correct option (A/B/C/D): ");
        String correctOption = scanner.nextLine().toUpperCase();

        questions.add(new Question(questionText, optionA, optionB, optionC, optionD, correctOption));
        System.out.println("Question added successfully.");
    }

    private static void takeQuiz(Scanner scanner) {
        if (questions.isEmpty()) {
            System.out.println("No questions available. Please add questions first.");
            return;
        }

        Collections.shuffle(questions);
        int score = 0;

        System.out.println("\nStarting Quiz...");
        for (int i = 0; i < questions.size(); i++) {
            Question question = questions.get(i);
            System.out.println("\nQuestion " + (i + 1) + ": " + question.getQuestionText());
            System.out.println("A. " + question.getOptionA());
            System.out.println("B. " + question.getOptionB());
            System.out.println("C. " + question.getOptionC());
            System.out.println("D. " + question.getOptionD());

            System.out.print("Your answer: ");
            String answer = scanner.nextLine().toUpperCase();

            if (answer.equals(question.getCorrectOption())) {
                System.out.println("Correct!");
                score++;
            } else {
                System.out.println("Wrong. The correct answer is " + question.getCorrectOption() + ".");
            }
        }

        System.out.println("\nQuiz Completed!");
        System.out.println("Your score: " + score + " out of " + questions.size());
    }
}

class Question {
    private final String questionText;
    private final String optionA;
    private final String optionB;
    private final String optionC;
    private final String optionD;
    private final String correctOption;

    public Question(String questionText, String optionA, String optionB, String optionC, String optionD, String correctOption) {
        this.questionText = questionText;
        this.optionA = optionA;
        this.optionB = optionB;
        this.optionC = optionC;
        this.optionD = optionD;
        this.correctOption = correctOption;
    }

    public String getQuestionText() {
        return questionText;
    }

    public String getOptionA() {
        return optionA;
    }

    public String getOptionB() {
        return optionB;
    }

    public String getOptionC() {
        return optionC;
    }

    public String getOptionD() {
        return optionD;
    }

    public String getCorrectOption() {
        return correctOption;
    }
}
